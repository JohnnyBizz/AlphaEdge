import { redirect } from 'next/navigation'
import { createServerClient } from '@/lib/supabase'

export default async function HomePage() {
  const supabase = createServerClient()
  const { data: { session } } = await supabase.auth.getSession()
  redirect(session ? '/dashboard' : '/auth')
}
